# Element

Combine anything. Discover what the world hasn't named yet.

Element is a small iOS game in the spirit of Little Alchemy or Infinite Craft: you start with a handful of elements, drag or tap two together, and get something new. There are two worlds to play in: **Classic** (Fire, Water, Earth, Air) and **Periodic** (real chemical elements that combine into compounds and materials). Past the starting recipes, every combination is generated on the spot by Apple's on-device Foundation Models framework, so no two playthroughs necessarily land on the same result for an unusual pair.

This started as a SwiftUI mini project and grew into something a bit bigger: a drag-and-drop crafting canvas, a persistent discovery log backed by Core Data, and a bonus map screen showing where each element was "discovered."

**Classic mode**

| Craft | Discoveries | Atlas |
| --- | --- | --- |
| ![Craft screen](Screenshots/craft.png) | ![Discoveries screen](Screenshots/discoveries.png) | ![Atlas screen](Screenshots/atlas.png) |

**Switching modes, and Periodic mode**

| Mode switcher | Periodic Craft | Periodic Discoveries |
| --- | --- | --- |
| ![Mode switcher](Screenshots/modes.png) | ![Periodic Craft screen](Screenshots/periodic-craft.png) | ![Periodic Discoveries screen](Screenshots/periodic-discoveries.png) |

## How it works

Pick two elements and combine them. If that exact pair has been combined before, in this session or a previous one, you get the cached result instantly. Otherwise, the app asks the on-device language model to invent something, using a short prompt modeled after how Infinite Craft itself seems to work: a terse `"Water" + "Earth" = ?` style question rather than a full sentence, which keeps answers grounded (a common noun, not a rambling description). Each mode's well-known starting pairs (Fire+Water = Steam and Water+Earth = Plant in Classic, Hydrogen+Oxygen = Water and Sodium+Chlorine = Salt in Periodic) are pinned to their real results, so the start of the game feels consistent; everything past that is genuinely generated.

Nothing here calls out to the internet. The model runs entirely on-device through Apple Intelligence, which is also why it needs a fairly specific setup to run at all (see below).

## Game modes

There are two worlds, switched from the title on the Craft screen (or in Settings). Each keeps its own discoveries and recipes, so switching never loses progress.

- **Classic**: start with Fire, Water, Earth, and Air.
- **Periodic**: start with eight real chemical elements (hydrogen, oxygen, carbon, nitrogen, sodium, chlorine, iron, sulfur) and combine them into compounds, minerals, and materials. Hydrogen + oxygen is water, sodium + chlorine is salt, iron + carbon is steel. Each element and compound's description starts with its symbol or formula.

Each mode has its own AI prompt, its own pinned starting recipes, and its own offline backup recipes.

## Screens

**Craft** is the main screen, laid out like Infinite Craft: tap an element in the tray to drop it on the canvas, or press and hold it to drag it out (straight onto another tile combines them immediately). Drop one tile onto another to combine them; the result appears where the target was, with a "New Discovery" toast and a burst for first-time finds. Double-tap a tile to duplicate it (handy for Fire + Fire), and drag a tile back into the tray to remove it. The tray can be searched, sorted, and expanded into a full grid.

**Discoveries** is a searchable log of everything you've found, with a favorites filter and a JSON export you can share. Each element's detail page lists the recipes that make it and what it combines into.

**Atlas** drops a pin for every element you've discovered on a world map, at a spot derived from its name so it's the same every time you look. Mostly decorative, but it was a fun excuse to use MapKit.

Settings lets you pick how "grounded" the AI should be (closer to the obvious answer versus more original), toggle reduced motion, switch between light/dark/system appearance, and reset your progress.

## Requirements

This needs iOS 26 (or the matching Simulator runtime) and a Mac with Apple Intelligence turned on, since Foundation Models runs through the same on-device pipeline. If you open the app and see a banner saying Apple Intelligence isn't ready, that's not a bug: check System Settings > Apple Intelligence & Siri on your Mac and make sure the model has finished downloading.

- Xcode 26+
- macOS and Simulator runtime both on 26.x (mismatched versions are a common source of "model catalog" errors)
- Apple Intelligence enabled and downloaded on the host Mac

## Running it

Open `Element.xcodeproj` in Xcode and run on a Simulator or device running iOS 26+. There's no backend, no API keys, and no third-party dependencies to install.

If you just want to sanity-check that Foundation Models is working on your machine without running the full app, an Xcode Playground with `import Playgrounds` and a quick `LanguageModelSession` call is the fastest way to check.

## Project layout

- `Element.swift`: the `Element` model and `GeneratedElement`, the `@Generable` struct the model fills in
- `GameViewModel.swift`: owns the discovered elements, the combination cache, the prompt, and the Core Data plumbing
- `CraftView.swift`: the drag-and-drop canvas and tray
- `DiscoveryLogView.swift` / `ElementDetailView.swift`: the discoveries list and detail screen
- `AtlasView.swift` / `LocationManager.swift`: the map screen
- `SettingsView.swift`: AI creativity, appearance, and reset
- `GameMode.swift`: the Classic and Periodic worlds: starting elements, pinned recipes, and AI prompts
- `Persistence.swift` / `Model.xcdatamodeld`: the Core Data stack
- `ElementPill.swift`: the emoji + name chip and the wrapping `FlowLayout` used by the tray
- `ElementTile.swift` / `Blob.swift`: shared UI pieces

## What this covers, for the curious

Built as a SwiftUI mini project, so it deliberately touches a wide spread of the framework: declarative view composition, `@State`/`@Binding`/`@Observable` for state management, `@AppStorage` and `@SceneStorage` for lightweight persistence, gestures (drag, tap, double-tap), `NavigationStack` with typed navigation, custom `Shape`/`Path` drawing, animations and transitions, Core Data with `@FetchRequest` and `NSPredicate`, and MapKit with `CLLocationManager`.

Left out on purpose: any real network calls (the whole point is that it's offline), and CoreML/Vision, since there wasn't an honest way to fit an image classifier into a text-combination game without it feeling bolted on.

## Why no combination table

Because that's the entire point. A hardcoded table of "Fire + Water = Steam" is what every other version of this game already does. The interesting part here is that the model is actually deciding, which means the game can genuinely surprise you, for better or worse.

There is one small table, but only as a safety net. If the model is unavailable, errors out, takes longer than 10 seconds, or just repeats one of the inputs back ("Smoke + Smoke = Smoke"), `RecipeBook.swift` answers instead, so a combination never ends in an error. It has about 100 hand-written recipes (Smoke + Smoke = Smog, Lava + Water = Stone), and anything beyond those gets an Infinite Craft-style compound like "Flying Lava" or "Living Stone". Only the model's answers are cached; fallback results aren't saved as recipes, so the model gets another try at that pair next time.
